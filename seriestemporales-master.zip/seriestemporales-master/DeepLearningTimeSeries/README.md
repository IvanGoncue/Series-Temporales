# Aproximación al análisis, estudio y predicción de Series temporales con DeepLearning

